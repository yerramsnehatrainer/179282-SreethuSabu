package com.ust.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Bank;
import com.ust.model.Response;
import com.ust.repositories.BankRepo;

@Service
public class BankService {

	@Autowired
	private BankRepo repo;
	List<Bank> list1 = new ArrayList<>();

	public Response showList() {

		list1 = repo.findAll();
		Response res = new Response();
		if (!list1.isEmpty()) {
			res.setStatus("Below List of Product Avilable In DB");
			res.setBank(list1);
		} else {
			res.setStatus("list is empty..!");
		}
		return res;
	}

	public Response addBank(Bank bank) {
		Bank prod = repo.save(bank);
		Response response = new Response();
		if (prod != null) {
			response.setStatus("Product Added in DB Successfully...!");
			list1.add(prod);
			response.setBank(list1);
		} else {
			response.setStatus("Product  Not Added in DB ...!");
			list1.add(bank);
			response.setBank(list1);
		}
		return response;
	}

	public Response deleteBank(Bank bank) {
		Bank p = repo.findById(bank.getBranch_Id()).get();
		Response response = new Response();
		if (p != null) {
			repo.delete(bank);
			response.setStatus("Data Deleted Successfully...!");
		} else {
			response.setStatus("Data Not Avilable in DB ...!");
		}
		return response;
	}

	public Response updateBank(Bank bank) {
		Bank bk = repo.findById(bank.getBranch_Id()).get();
		Response response = new Response();
		if (bk != null) {
			if(null != bank.getIfsc_code()) {
				bk.setIfsc_code(bank.getIfsc_code());
			}
			if(null != bank.getLocation()) {
				bk.setLocation(bank.getLocation());
			}
			repo.save(bk);
			list1.clear();
			list1.add(bk);
			response.setBank(list1);
		}

		return response;
	}

}
